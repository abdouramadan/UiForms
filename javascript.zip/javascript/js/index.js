// let displayDate = document.querySelector('.show-date>h1'),
//     displayTime = document.querySelector('.show-time>h1'),
//     greeting    = document.querySelector('.show-date>h2');

// let hour    = new Date().getHours(),
//     min     = new Date().getMinutes(),
//     sec     = new Date().getSeconds(),
//     merdian = 'PM',
//     Hzero   = '',
//     Mzero   = '';

// let days    = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
//     months  = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
//     date    = new Date();


// setInterval(() => {

//     if(sec === 60){ sec = 1; min = min + 1 }

//     sec <= 9 ? sec = '0' + sec : '';

//     if (min === 60) { min = 1 ; hour++ }

//     hour >= 12 ? merdian = 'PM' : merdian = 'AM';

//     hour <= 9 ? Hzero = '0' : Hzero = '';

//     min <= 9 ? Mzero = '0' : Mzero = '';

//     merdian === 'PM' ? greeting.textContent = 'hi maria! good evening' : greeting.textContent = 'hi maria! good morning';

//     displayTime.textContent = Hzero + hour + ' : ' + Mzero + min + ' : ' + sec + ' ' + merdian;

//     displayDate.textContent = days[date.getDay()] + ' ' + date.getDate() + ' ' + months[date.getMonth()];

//     sec++;

// }, 1000);